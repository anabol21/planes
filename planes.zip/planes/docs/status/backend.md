---
workstream: backend
owner: Ruslan
task: INT-001
status: review
updated: 2026-09-24
checkpoint: 2026-09-23
branch: main
contract_version: v0
---

# Backend status

- `planned`: RUS-002 — рельеф из отдельного KML местности в матрицы `precompute`. Бриф: `docs/workstreams/model/RUS-002.md`.

Live path on `main`: the form at `127.0.0.1:5173` sends `aerodromes` and `boards`, not `pads` or `uav_types`, to the API at `127.0.0.1:8000`. The live worker is `python -m planes.backend.worker --engine runtime`. The CLI default remains `fake`. SQLite stores `scenario_json` unchanged. Catalog numbers, including optics and power, are applied only on the listener. `fleet_catalog.json` is filled from Grisha's `data.json`; `geoscan-801` is his 1.5 kg quadcopter. GSD, overlaps, and strip direction come from the form. The listener is `planes-compute.service` at `/opt/planes`, git `da3da56` on `runtime/MIS-002-external-enumeration`, health `live`, contract `v0`, `solver_choice` `meta`. Documentation commit `794fb2d` was not deployed there. See `docs/architecture/agent-brief-backend.md` and `docs/architecture/agent-brief-runtime.md`. Remaining approximations (`geoscan-201` `kh`/`kv`/`kw` `90`/`0.02`/`0.008` instead of `220` W, `turn_time_s` `5.0`, `apply_turn_to_base` `false`, zones and obstacles not copied into `InputData`) are in the runtime brief.

## Completed

- [x] Described the 12-step product pipeline and data lifecycle.
- [x] Proposed API/worker separation, polling, and SQLite for the prototype.
- [x] Added backend-local immutable `ComputeRequest` and `ComputeResponse` v0 structures.
- [x] Added the backend-facing `OptimizationEngine` protocol and deterministic fake engine.
- [x] Added SQLite job persistence with immutable serialized input snapshots.
- [x] Added atomic `queued -> running` worker claim using `BEGIN IMMEDIATE` and a conditional update.
- [x] Added thin standard-library WSGI handlers for `POST /jobs`, `GET /jobs/{id}`, and `GET /jobs/{id}/result`.
- [x] Added separate-process worker CLI and structured feasible, infeasible, timeout, and error handling.
- [x] Added a backend-local v0 submission fixture and deterministic lifecycle tests.
- [x] Added the backend-owned `RuntimeOptimizationEngine` conversion wrapper around the unchanged runtime adapter.
- [x] Added explicit worker selection through `--engine fake|runtime`, defaulting to the existing fake.
- [x] Added deterministic runtime conversion and lifecycle tests using an injected adapter stub.

## In progress

- [ ] Independent review and agreement on the future shared JSON contract/fixtures.

## Next action

The live worker path is `--engine runtime` against the listener recorded in `docs/architecture/agent-brief-runtime.md` (git `da3da56`, not documentation commit `794fb2d`). The earlier note that a controlled smoke was not recorded in this file stays as checkpoint evidence.

## Evidence

- Task brief: `docs/workstreams/backend/RUS-001.md`.
- `python -m compileall -q src/planes/backend tests/backend` — passed (exit 0).
- `python -m unittest discover -s tests/backend -v` — passed, 20 tests, `OK`.
- `python scripts/validate_workspace.py` — `Workspace validation: PASS`.
- `git diff --check` — passed (exit 0).
- Landed on the integration branch in `02011ce` (merge of `0d61960`). Re-checked here: `python3 -m compileall -q src/planes/backend tests/backend` exit 0; `PYTHONPATH=src python3 -m unittest discover -s tests/backend -v` — `Ran 20 tests in 0.876s` / `OK`. `python3 scripts/validate_workspace.py` — `Workspace validation: PASS`. Runtime contour re-checked with `PYTHONPATH=src python3 -m unittest discover -s tests/runtime -v` — `Ran 28 tests in 7.244s` / `OK`. `src/planes/contracts/**` and `src/planes/runtime/**` were not modified.
- INT-001 compile/import check: `python -m compileall -q src/planes/backend tests/backend` — passed.
- INT-001 full suite: `python -m unittest discover -s tests/backend -v` — passed, 32 tests, `OK`.
- INT-001 focused suite: `python -m unittest tests.backend.test_runtime_engine -v` — passed, 12 tests, `OK`.
- Worker help: `PYTHONPATH=src python -m planes.backend.worker --help` — passed and exposes `--engine {fake,runtime}`.
- INT-001 workspace validation and `git diff --check` both passed.
- Real VPS smoke was not performed because `COMPUTE_HOST`, `COMPUTE_TOKEN`, and `COMPUTE_TIMEOUT_SECONDS` were all absent.
- Direct WSGI-callable tests cover the three routes, validation failures, unknown jobs, result-not-ready, every terminal lifecycle mapping, unsupported methods, and unknown paths.
- `test_worker_cli_processes_job_in_separate_process` verifies one worker CLI run in a separate Python subprocess with `PYTHONPATH=src`.
- `test_socket_bound_api_submit_and_status` starts the standard-library WSGI server on localhost with an ephemeral port and verifies real HTTP `POST /jobs` and `GET /jobs/{id}` responses before clean shutdown.

## Manual HTTP run instructions

These are reproducible manual instructions, not evidence of a separately executed manual run. Run from the repository root in PowerShell, using separate terminals for API and worker:

```powershell
$env:PYTHONPATH = "src"
python -m planes.backend.api --database .\tests\backend\local-run.sqlite3
```

```powershell
$body = Get-Content .\tests\backend\fixtures\job_submission_v0.json -Raw
$job = Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/jobs -ContentType application/json -Body $body
$env:PYTHONPATH = "src"
python -m planes.backend.worker --database .\tests\backend\local-run.sqlite3
Invoke-RestMethod -Uri "http://127.0.0.1:8000/jobs/$($job.job_id)"
Invoke-RestMethod -Uri "http://127.0.0.1:8000/jobs/$($job.job_id)/result"
```

Automated evidence is recorded above: direct WSGI tests exercise handler behavior, the socket smoke test binds a real localhost port, and the subprocess test executes the worker CLI.

The commands above follow the CLI default `--engine fake` and are the recorded prototype instructions. The live path adds `--engine runtime` and the worker-only `COMPUTE_HOST`, `COMPUTE_TOKEN`, and `COMPUTE_TIMEOUT_SECONDS` values, supplied outside Git. SQLite still stores the scenario unchanged. See `docs/architecture/agent-brief-backend.md`.

## Blockers / decisions requested

- The shared domain schemas and runtime-facing JSON fixtures remain unfrozen under `OPEN-001..006`, `OPEN-019`, and `OPEN-021`; the committed fixture and structures are backend-local only.
- No external HTTP framework is declared in the repository, so the prototype uses the Python standard-library WSGI server rather than introducing an out-of-scope dependency.
- Prototype recovery policy for a worker that dies after claiming a job is intentionally not defined. Such a job remains `running` rather than being silently duplicated or reported successful.
- Earlier checkpoint: this file did not record a VPS smoke, because `COMPUTE_HOST`, `COMPUTE_TOKEN`, and `COMPUTE_TIMEOUT_SECONDS` were absent during that check. The listener now recorded in `docs/architecture/agent-brief-runtime.md` is git `da3da56`. Those three values stay outside Git.

## Interface changes

- Added a backend-local `OptimizationEngine.solve(ComputeRequest) -> ComputeResponse` port matching `INTERFACES_V0.md`; no shared contract or architecture file changed.
- Runtime can supply an adapter through worker composition without changing API, service, or storage code.
- Runtime mode converts through runtime-owned `parse_request` and `response_to_dict`; fake-only optimization fields are not forwarded.
- Runtime feasible/infeasible responses map to `completed`, timed-out maps to `timed_out`, and runtime/config/transport errors map to `failed`.
- The worker CLI defaults to `fake`; runtime is selected only with `--engine runtime`, never implicitly from environment-variable presence.
- API responses and persistence are explicitly versioned `v0`; `POST /jobs` accepts an omitted `contract_version` and defaults it to `v0`, while rejecting other versions. Feasible and infeasible map to lifecycle `completed`; timeout maps to `timed_out`; engine errors map to `failed`.
